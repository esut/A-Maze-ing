import sys
import os
from typing import Dict, Any, Optional
from .config_parser import parse_config
from .maze_generator import MazeGenerator, get_42_cells
from .maze_solver import solve_maze
from .maze_writer import write_maze
from .display import display_maze


def validate_config(config: Dict[str, Any]) -> None:
    """Validate configuration values.

    Args:
        config: Configuration dictionary

    Raises:
        ValueError: If configuration values are invalid
    """
    width: int = config["WIDTH"]
    height: int = config["HEIGHT"]
    entry: tuple[int, int] = config["ENTRY"]
    exit_: tuple[int, int] = config["EXIT"]

    if width <= 0 or height <= 0:
        raise ValueError("WIDTH and HEIGHT must be positive integers")
    if not (0 <= entry[0] < width and 0 <= entry[1] < height):
        raise ValueError("ENTRY coordinates are outside the maze")
    if not (0 <= exit_[0] < width and 0 <= exit_[1] < height):
        raise ValueError("EXIT coordinates are outside the maze")
    if entry == exit_:
        raise ValueError("ENTRY and EXIT must be different")

    blocked = set(get_42_cells(width, height))
    if entry in blocked:
        raise ValueError(
            f"ENTRY {entry} overlaps with the '42' pattern cells"
        )
    if exit_ in blocked:
        raise ValueError(
            f"EXIT {exit_} overlaps with the '42' pattern cells"
        )


def main() -> None:
    """Main entry point for the maze generator."""
    if len(sys.argv) == 1:
        config_file: str = os.path.join(os.path.dirname(__file__), "config.txt")
    elif len(sys.argv) == 2:
        config_file = sys.argv[1]
    else:
        print("Usage: mazegen [config.txt]")
        sys.exit(1)

    try:
        config: Dict[str, Any] = parse_config(config_file)
        validate_config(config)

        seed: Optional[int] = config.get("SEED", None)
        entry: tuple[int, int] = config["ENTRY"]
        exit_: tuple[int, int] = config["EXIT"]
        perfect: bool = config["PERFECT"]

        generator: MazeGenerator = MazeGenerator(
            config["WIDTH"], config["HEIGHT"], seed
        )
        maze = generator.generate(
            entry=entry, exit_=exit_, perfect=perfect
        )

        path: str = solve_maze(maze, entry, exit_)

        write_maze(config["OUTPUT_FILE"], maze, entry, exit_, path)

        print("\nMaze generated successfully\n")
        print("Shortest path:", path)

        display_maze(
            maze,
            entry=entry,
            exit_=exit_,
            width=config["WIDTH"],
            height=config["HEIGHT"],
            perfect=perfect,
            seed=seed,
        )

    except FileNotFoundError:
        print(f"Error: file '{config_file}' not found")
    except ValueError as e:
        print("Configuration error:", e)
    except KeyError as e:
        print(f"Missing configuration key: {e}")
    except Exception as e:
        print("Unexpected error:", e)


if __name__ == "__main__":
    main()